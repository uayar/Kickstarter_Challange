Kickstarting with Excel

1. Overview of Project
Kickstarter_Challange workbook provides a statistical overview for the projects in the theater industry focusing on the outcomes per project launch dates and goals.

1.1. Purpose
The purpose of this workbook is to provide an overview for project outcomes based on launch date and goals of the previous projects that were launched between mid 2009 and early 2017. 


2. Analysis and Challenges
Outcomes of the projects were analyzed based on launch date and goals. There were some challanges encountered during the data analysis process due to improper data format and categorization.

2.1. Analysis of Outcomes Based on Launch Date
In this section, campaign outcomes were analized based on the launch dates of projects to identify the most suitable and least suitable months to launch a project. Refer to section 4 for the results.

2.2. Analysis of Outcomes Based on Goals
In this section, campaign outcomes were analized based on the project goals to identify the most suitable and least suitable amounts to launch a project. Refer to section 4 for the results.

2.3. Challenges and Difficulties Encountered
There were some challanges encountered during the data analysis process caused by the original worksheet due to improper data formatting and categorization, such as the date formats for launch and dealine were provided only in a machine-readable format, also category and subcategory tab required to be seperated so more specific data analysis could be performed per the scope of the work.


3. Results
Base on the project launch dates, Jun and July were determined to be the most suitable months to lauch a project with 68% and 67% success rates, 30% and 31% failure rates respectively, and they both have 2% cancellation rate. The least suitable month was determined to be January with 50% success rate, 45% failure rate, and 5% cancellation rate.

It was also determined that the projects with goals of less than $1000 and projects with goals from $1000 to $4999 have higher chances to succeed with 100% and 73% success rates, 0% and 27% failure rates respectively, and they both have 0% cancellation rate. Please note that the projects with goals of more than $50000 has also a success rate of 100%, however these projects were ruled out due to negligable number of projects launched.

There were some challanges encountered during the data analysis process due to improper data format and categorization.

In addition to the areas analyzed, pledged values and targeted countries should also be analyzed to get more comprehensive data, and a descriptive statistical analysis should be performed to obtain a higher level understading in the industry. 

